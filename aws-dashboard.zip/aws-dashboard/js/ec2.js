async function loadEC2(region) {
    try {
      const res = await fetch(`${API_BASE_URL}/api/ec2?region=${region}`);
      const data = await res.json();
  
      const running = data.filter(i => i.state === 'running').length;
      const stopped = data.filter(i => i.state === 'stopped').length;
      document.getElementById('running-count').textContent = running;
      document.getElementById('stopped-count').textContent = stopped;
  
      const table = document.getElementById('instances-table');
      table.innerHTML = '';
      data.forEach(instance => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td class="py-2">
            <div><b>${instance.id}</b></div>
            <div>${instance.name}</div>
            <div class="text-sm text-gray-400">Public IP: ${instance.publicIp}</div>
            <div class="text-sm text-gray-400">Private IP: ${instance.privateIp}</div>
            <div class="mt-1">
              <button onclick="controlEC2('start', '${instance.id}', '${region}')" class="bg-green-500 text-sm px-2 py-1 rounded">Start</button>
              <button onclick="controlEC2('stop', '${instance.id}', '${region}')" class="bg-yellow-500 text-sm px-2 py-1 rounded ml-1">Stop</button>
              <button onclick="controlEC2('reboot', '${instance.id}', '${region}')" class="bg-blue-500 text-sm px-2 py-1 rounded ml-1">Reboot</button>
            </div>
          </td>
          <td>
            <canvas id="chart-${instance.id}" width="250" height="80"></canvas>
          </td>
        `;
        table.appendChild(tr);
  
        renderChart(`chart-${instance.id}`);
      });
    } catch (err) {
      console.error('Failed to load EC2:', err);
    }
  }
  
  async function controlEC2(action, instanceId, region) {
    try {
      await fetch(`${API_BASE_URL}/api/ec2/${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ instanceId, region })
      });
      loadEC2(region);
    } catch (err) {
      alert(`Failed to ${action} instance`);
    }
  }
  
  function renderChart(canvasId) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: Array.from({ length: 10 }, (_, i) => `-${10 - i}m`),
        datasets: [
          {
            label: 'CPU',
            data: Array(10).fill().map(() => Math.random() * 100),
            borderColor: 'cyan',
            borderWidth: 1,
            fill: false,
          },
          {
            label: 'Network In',
            data: Array(10).fill().map(() => Math.random() * 5),
            borderColor: 'lime',
            borderWidth: 1,
            fill: false,
          },
          {
            label: 'Network Out',
            data: Array(10).fill().map(() => Math.random() * 5),
            borderColor: 'magenta',
            borderWidth: 1,
            fill: false,
          },
        ],
      },
      options: {
        responsive: false,
        plugins: {
          legend: { display: true, position: 'bottom' }
        },
        scales: {
          y: { beginAtZero: true }
        }
      }
    });
  }  