async function loadS3() {
    try {
      const res = await fetch(`${API_BASE_URL}/api/s3`);
      const data = await res.json();
  
      const table = document.getElementById('buckets-table');
      table.innerHTML = '';
      data.forEach(bucket => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td class="py-2">${bucket.name}</td>
          <td>${bucket.region}</td>
          <td>${new Date(bucket.creationDate).toLocaleString()}</td>
          <td>${bucket.storageMiB} MiB</td>
        `;
        table.appendChild(tr);
      });
    } catch (err) {
      console.error('Failed to load S3:', err);
    }
  }  