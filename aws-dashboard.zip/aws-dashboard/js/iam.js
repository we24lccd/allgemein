async function loadIAM() {
    try {
      const res = await fetch(`${API_BASE_URL}/api/iam`);
      const data = await res.json();
  
      const table = document.getElementById('iam-users-table');
      table.innerHTML = '';
      data.forEach(user => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td class="py-2">${user.userName}</td>
          <td>${user.userId}</td>
          <td>${new Date(user.createDate).toLocaleString()}</td>
          <td class="text-sm text-gray-300">${user.arn}</td>
        `;
        table.appendChild(tr);
      });
    } catch (err) {
      console.error('Failed to load IAM:', err);
    }
  }  