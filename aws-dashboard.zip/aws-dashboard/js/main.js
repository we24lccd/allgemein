const btnEC2 = document.getElementById('btn-ec2');
const btnS3 = document.getElementById('btn-s3');
const btnIAM = document.getElementById('btn-iam');
const dashboardEC2 = document.getElementById('dashboard-ec2');
const dashboardS3 = document.getElementById('dashboard-s3');
const dashboardIAM = document.getElementById('dashboard-iam');
const ec2Content = document.getElementById('ec2-content');
const s3Content = document.getElementById('s3-content');
const iamContent = document.getElementById('iam-content');

btnEC2.addEventListener('click', () => {
    dashboardEC2.classList.remove('hidden');
    dashboardS3.classList.add('hidden');
    dashboardIAM.classList.add('hidden');
    updateEC2Dashboard();
});

btnS3.addEventListener('click', () => {
    dashboardS3.classList.remove('hidden');
    dashboardEC2.classList.add('hidden');
    dashboardIAM.classList.add('hidden');
    updateS3Dashboard();
});

btnIAM.addEventListener('click', () => {
    dashboardIAM.classList.remove('hidden');
    dashboardEC2.classList.add('hidden');
    dashboardS3.classList.add('hidden');
    updateIAMDashboard();
});

async function fetchData(url) {
    const res = await fetch(url);
    return await res.json();
}

async function updateEC2Dashboard() {
    const data = await fetchData('/api/ec2');
    ec2Content.innerHTML = data.map(instance => `
        <div>
            <strong>Instance ID:</strong> ${instance.id} <br>
            <strong>Name:</strong> ${instance.name} <br>
            <strong>State:</strong> ${instance.state} <br>
            <strong>Public IP:</strong> ${instance.publicIp} <br>
            <strong>Private IP:</strong> ${instance.privateIp} <br><br>
        </div>
    `).join('');
}

async function updateS3Dashboard() {
    const data = await fetchData('/api/s3');
    s3Content.innerHTML = data.map(bucket => `
        <div>
            <strong>Bucket Name:</strong> ${bucket.name} <br>
            <strong>Region:</strong> ${bucket.region} <br>
            <strong>Created On:</strong> ${bucket.creationDate} <br>
            <strong>Storage (MiB):</strong> ${bucket.storageMiB} <br><br>
        </div>
    `).join('');
}

async function updateIAMDashboard() {
    const data = await fetchData('/api/iam');
    iamContent.innerHTML = data.map(user => `
        <div>
            <strong>User Name:</strong> ${user.userName} <br>
            <strong>User ID:</strong> ${user.userId} <br>
            <strong>Created On:</strong> ${user.createDate} <br>
            <strong>ARN:</strong> ${user.arn} <br><br>
        </div>
    `).join('');
}