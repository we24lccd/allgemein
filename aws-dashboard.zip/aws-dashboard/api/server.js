// Import các module
const express = require('express');
const path = require('path');  // Để xử lý đường dẫn tệp tĩnh
const AWS = require('aws-sdk');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Cấu hình Express để phục vụ các tệp tĩnh từ thư mục gốc (root folder)
app.use(express.static(path.join(__dirname, '../'))); // Từ thư mục 'api', phục vụ tệp từ thư mục gốc

// Route cho trang chủ
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../index.html'));  // Đảm bảo trả về file index.html từ thư mục gốc
});

// EC2 Routes
app.get('/api/ec2', async (req, res) => {
  const region = req.query.region || 'us-east-1';
  AWS.config.update({ region });
  const ec2 = new AWS.EC2();

  try {
    const { Reservations } = await ec2.describeInstances().promise();
    const instances = [];

    for (const r of Reservations) {
      for (const i of r.Instances) {
        instances.push({
          id: i.InstanceId,
          name: (i.Tags.find(tag => tag.Key === 'Name') || {}).Value || 'N/A',
          state: i.State.Name,
          publicIp: i.PublicIpAddress || '-',
          privateIp: i.PrivateIpAddress || '-',
        });
      }
    }

    res.json(instances);
  } catch (err) {
    console.error('Error fetching EC2 data:', err);
    res.status(500).json({ error: 'Failed to fetch EC2 data' });
  }
});

// S3 Routes
app.get('/api/s3', async (req, res) => {
  const s3 = new AWS.S3();

  try {
    const { Buckets } = await s3.listBuckets().promise();
    const results = await Promise.all(
      Buckets.map(async bucket => {
        const { LocationConstraint } = await s3.getBucketLocation({ Bucket: bucket.Name }).promise().catch(() => ({ LocationConstraint: 'us-east-1' }));
        return {
          name: bucket.Name,
          region: LocationConstraint || 'us-east-1',
          creationDate: bucket.CreationDate,
          storageMiB: Math.floor(Math.random() * 500), // Optional: use AWS S3 analytics/metrics for real size
        };
      })
    );

    res.json(results);
  } catch (err) {
    console.error('Error fetching S3 data:', err);
    res.status(500).json({ error: 'Failed to fetch S3 buckets' });
  }
});

// IAM Routes
app.get('/api/iam', async (req, res) => {
  const iam = new AWS.IAM();

  try {
    const { Users } = await iam.listUsers().promise();
    res.json(Users.map(user => ({
      userName: user.UserName,
      userId: user.UserId,
      createDate: user.CreateDate,
      arn: user.Arn,
    })));
  } catch (err) {
    console.error('Error fetching IAM users:', err);
    res.status(500).json({ error: 'Failed to fetch IAM users' });
  }
});

app.listen(3000, () => {
  console.log('API server đang chạy tại http://localhost:3000');
});