const express = require('express');
const AWS = require('aws-sdk');
const router = express.Router();

// GET /api/iam
router.get('/', async (req, res) => {
  const iam = new AWS.IAM();

  try {
    const { Users } = await iam.listUsers().promise();
    res.json(Users.map(user => ({
      userName: user.UserName,
      userId: user.UserId,
      createDate: user.CreateDate,
      arn: user.Arn,
    })));
  } catch (err) {
    console.error('Error fetching IAM users:', err);
    res.status(500).json({ error: 'Failed to fetch IAM users' });
  }
});

module.exports = router;