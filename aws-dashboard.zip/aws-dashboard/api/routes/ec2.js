const express = require('express');
const AWS = require('aws-sdk');
const router = express.Router();

// GET /api/ec2
router.get('/', async (req, res) => {
  const region = req.query.region || 'us-east-1';
  AWS.config.update({ region });

  const ec2 = new AWS.EC2();
  try {
    const { Reservations } = await ec2.describeInstances().promise();
    const instances = [];

    for (const r of Reservations) {
      for (const i of r.Instances) {
        instances.push({
          id: i.InstanceId,
          name: (i.Tags.find(tag => tag.Key === 'Name') || {}).Value || 'N/A',
          state: i.State.Name,
          publicIp: i.PublicIpAddress || '-',
          privateIp: i.PrivateIpAddress || '-',
          metrics: {
            timestamps: [], cpu: [], networkIn: [], networkOut: [],
          }
        });
      }
    }

    res.json(instances);
  } catch (err) {
    console.error('EC2 fetch error:', err);
    res.status(500).json({ error: 'Failed to fetch EC2 data' });
  }
});

// POST /api/ec2/:action
router.post('/:action', async (req, res) => {
  const { action } = req.params;
  const { instanceId, region } = req.body;
  AWS.config.update({ region });

  const ec2 = new AWS.EC2();

  try {
    if (action === 'start') await ec2.startInstances({ InstanceIds: [instanceId] }).promise();
    else if (action === 'stop') await ec2.stopInstances({ InstanceIds: [instanceId] }).promise();
    else if (action === 'reboot') await ec2.rebootInstances({ InstanceIds: [instanceId] }).promise();
    else return res.status(400).json({ error: 'Invalid action' });

    res.json({ success: true });
  } catch (err) {
    console.error(`EC2 ${action} error:`, err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;