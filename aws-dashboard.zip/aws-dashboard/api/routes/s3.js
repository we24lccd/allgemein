const express = require('express');
const AWS = require('aws-sdk');
const router = express.Router();

// GET /api/s3
router.get('/', async (req, res) => {
  const s3 = new AWS.S3();

  try {
    const { Buckets } = await s3.listBuckets().promise();
    const results = await Promise.all(
      Buckets.map(async bucket => {
        const { LocationConstraint } = await s3.getBucketLocation({ Bucket: bucket.Name }).promise().catch(() => ({ LocationConstraint: 'us-east-1' }));
        return {
          name: bucket.Name,
          region: LocationConstraint || 'us-east-1',
          creationDate: bucket.CreationDate,
          storageMiB: Math.floor(Math.random() * 500), // Optional: use AWS S3 analytics/metrics for real size
        };
      })
    );

    res.json(results);
  } catch (err) {
    console.error('Error fetching S3 data:', err);
    res.status(500).json({ error: 'Failed to fetch S3 buckets' });
  }
});

module.exports = router;